package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelService {

	
	public int addUserDetails(UserBean u);
	
	public int addHotelServ(HotelBean hotelbean);

	int addRoomServ(RoomBean roombean);

	public ArrayList<HotelBean> getAllHotels();

	public int deleteHotelById(int deletehotelid);
	
	boolean login(String userName, String password, UserBean userbean);

	public int deleteroomById(int deleteroomid);

	 public ArrayList<HotelBean> selecthotel(String location);

	public ArrayList<RoomBean> selectroom(int id);

	//int BookRoom(int hotelId, int perNight, int roomId, String bookedTo,String bookedFrom, int numberOfAdults);

	public void updateHotelDetails(HotelBean hotelBean);
	ArrayList<HotelBean> searchHotelById(int id);
	
	
	
		public void updateRoomDetails(RoomBean roomBean);
		
		ArrayList<RoomBean> searchRoomById(int id);

	

}
