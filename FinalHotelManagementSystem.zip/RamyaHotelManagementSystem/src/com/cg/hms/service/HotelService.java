package com.cg.hms.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
import com.cg.hms.dao.IHotelDao;

@Service
public class HotelService implements IHotelService{

	
	@Autowired
	private IHotelDao hdao;

	@Override
	public int addUserDetails(UserBean u) {
		int b=hdao.addUserDetails(u);
		
		return b;
	}

	@Override
	public boolean login(String userName, String password, UserBean userbean) {
		
		return  hdao.login(userName,password,userbean);
	}
	
	@Override
	public int addHotelServ(HotelBean hotelbean) {
		System.out.println("inside service");
		int bookhotel=hdao.addHotelServ(hotelbean);
		
		return bookhotel;
	}

	@Override
	public int addRoomServ(RoomBean roombean) {
		System.out.println("inside service");
		int bookroom=hdao.addRoomServ(roombean);
		
		return bookroom;
	}

	@Override
	public ArrayList<HotelBean> getAllHotels() {
		
		return hdao.getAllHotels();
	}

	@Override
	public int deleteHotelById(int deletehotelid) {
		System.out.println("inside service deletehotelid");
		return hdao.deleteHotelById(deletehotelid);
	}

	@Override
	public int deleteroomById(int deleteroomid) {
		System.out.println("inside service deleteroomid");
		return hdao.deleteroomById(deleteroomid);
	}

	@Override
	public ArrayList<HotelBean> selecthotel(String location) {
		
		return hdao.selecthotel(location);
	}

	@Override
	public ArrayList<RoomBean> selectroom(int id) {
	
		return hdao.selectroom(id);
	}
/*****************UPDATE HOTEL*********************/
	@Override
	public void updateHotelDetails(HotelBean hotelBean) 
	{
		hdao.updateHotelDetails(hotelBean);

	}
	@Override
	public ArrayList<HotelBean> searchHotelById(int id) {
		
		 return hdao.searchHotelById(id);

	}

@Override
public void updateRoomDetails(RoomBean roomBean) {
	hdao.updateRoomDetails(roomBean);
	
}



@Override
public ArrayList<RoomBean> searchRoomById(int id) {
	
	return hdao.searchRoomById(id);
}

	/*@Override
	public int BookRoom(int hotelId, int perNight, int roomId,String bookedTo, String bookedFrom, int numberOfAdults)
	{
		BookingDetailsBean bean=new BookingDetailsBean();
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
		java.util.Date d1=null;
		java.util.Date d2=null;
		try{
			d1=format.parse(bookedFrom);
			d2=format.parse(bookedTo);
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		int diff=(int) (d2.getTime()-d1.getTime());
		int diffDays=diff/(60*60*1000*24);
		System.out.println(diffDays);
		bean.setAmount(amount=(diffDays)*numberOfAdults*perNight);
	System.out.println("amount to be paid:"+amount);
		 return hdao.BookRoom(hotelId, perNight, roomId, bookedTo, bookedFrom, numberOfAdults,amount);
	
	}*/
}
