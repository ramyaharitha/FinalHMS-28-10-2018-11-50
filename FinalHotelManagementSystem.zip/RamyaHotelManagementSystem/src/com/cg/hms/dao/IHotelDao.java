package com.cg.hms.dao;

import java.util.ArrayList;

import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelDao 
{
	public int addUserDetails(UserBean u);

	public int addHotelServ(HotelBean hotelbean);

	public int addRoomServ(RoomBean roombean);

	public ArrayList<HotelBean> getAllHotels();



	public int deleteHotelById(int deletehotelid);

	
	public boolean login(String userName, String password, UserBean userbean);

	public int deleteroomById(int deleteroomid);

	public ArrayList<HotelBean> selecthotel(String location);

	public ArrayList<RoomBean> selectroom(int id);
	/******UPDATE HOTEL********/
	public void updateHotelDetails(HotelBean hotelBean);
	public ArrayList<HotelBean> searchHotelById(int id);
	
	
	
	public void updateRoomDetails(RoomBean roomBean);
	
	ArrayList<RoomBean> searchRoomById(int id);

	public int BookRoom(int hotelId, int perNight, int roomId, String bookedTo,
			String bookedFrom, int numberOfAdults, int amount);



}
